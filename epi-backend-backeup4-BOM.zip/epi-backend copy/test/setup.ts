/**
 * Este arquivo serve como um redirecionamento para o setup de integração
 * Mantido para compatibilidade com os testes existentes
 */

export * from './setup/integration-test-setup';
