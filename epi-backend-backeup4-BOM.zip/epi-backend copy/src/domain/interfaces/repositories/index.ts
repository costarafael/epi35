export * from './base.repository.interface';
export * from './estoque-repository.interface';
export * from './movimentacao-repository.interface';
export * from './nota-repository.interface';
export * from './colaborador-repository.interface';
export * from './contratada-repository.interface';
export * from './ficha-repository.interface';
export * from './entrega-repository.interface';