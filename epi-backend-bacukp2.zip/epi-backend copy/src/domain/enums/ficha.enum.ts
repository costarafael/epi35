export enum StatusFichaEPI {
  ATIVA = 'ATIVA',
  INATIVA = 'INATIVA',
}